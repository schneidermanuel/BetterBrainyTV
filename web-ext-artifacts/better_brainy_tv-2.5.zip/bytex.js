let emotes;
var xmlHttp = new XMLHttpRequest();
xmlHttp.open("GET", "https://build.brainyxs.com/bbtv/streamer-dashboard/api.php", false); // false for synchronous request
xmlHttp.send();
emotes = JSON.parse(xmlHttp.responseText);
console.log(emotes);

function loaded(youtubelive) {
    console.log("loaded");
    
    if (youtubelive instanceof YouTubeLive) {

        console.log("started");
        const ownUserName = $(".yt-live-chat-message-input-renderer #author-name")
            .text();
        youtubelive.registerChatMessageObserver(function (message) {
            let id = message.id.toString();
            let element = document.getElementById(id);
            if (!element) return;
            let innerElement = element.getElementsByTagName("div")[0].getElementsByClassName("yt-live-chat-text-message-renderer");

            if (innerElement === undefined || !innerElement[2]) {
                return;
            }
            let text = innerElement[2].innerHTML;
            let authorName = innerElement[1].innerText;
            let newtext = text;
            emotes.forEach(emote => {
                console.log(emote);
                newtext = newtext.replace(new RegExp(emote.EmoteName, "g"), "<img src=" + emote.EmoteHref + " >");

            })

            document.getElementById(id)
                .getElementsByTagName("div")[0].getElementsByClassName("yt-live-chat-text-message-renderer")[2].innerHTML = newtext;

            if (text === newtext) {
                return;
            }
            if (authorName !== ownUserName) {
                return;
            }
            let otext = newtext;
            let count = 0;
            let handler = function () {
                let id = message.id.toString();
                let diaplayed = document.getElementById(id)
                    .getElementsByTagName("div")[0].getElementsByClassName("yt-live-chat-text-message-renderer")[2].innerHTML;
                console.log("displayed: " + diaplayed);
                console.log("New " + newtext);
                count++;
                if (diaplayed === newtext) {
                    return false;
                }
                document.getElementById(id)
                    .getElementsByTagName("div")[0].getElementsByClassName("yt-live-chat-text-message-renderer")[2].innerHTML = otext;
                return true;
            };
            if (authorName === ownUserName && newtext !== text) {
                console.log("Changing");

                let changeDisplayed = function () {
                    let result = handler();
                    if (result) {
                        window.setTimeout(changeDisplayed, 100);
                    }
                }
                changeDisplayed();
            }
        }, true);
    }
}


YouTubeLive.onChatLoaded(ytlive => loaded(ytlive));
