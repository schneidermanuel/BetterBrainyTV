# Privacy Policy

## What personal data does BetterRBTV process?
BetterRBTV processes public chat messages in YouTube chats you visit in order to highlight, block or style messages, and provide similar functionality. Data you input into the chat input field is scanned for keywords to be replaced by emojis.

## What data does BetterRBTV transfer?
**None.** The extension operates locally on your computer.

If you enabled settings syncing in your browser, all extension settings will be synced with your browser's settings store. Please consult the browser's privacy policy for more information.
