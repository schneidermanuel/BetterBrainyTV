const BRBTV_DEBUG = false;
const BRBTV_COMMIT_VERSION = 174; // last commit # for which a message was generated containing useful information
const BRBTV_IS_FIREFOX = true;
